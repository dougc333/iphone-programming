//
//  BumpConnect.h
//  PistolGunVCTemplate
//
//  Created by doug chang on 12/17/10.
//  Copyright 2010 edu.canadacollege. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface BumpConnect : NSObject {

}

@end
