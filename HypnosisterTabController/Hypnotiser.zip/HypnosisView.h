//
//  HypnosisView.h
//  Hypnosister
//
//  Created by doug chang on 9/25/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface HypnosisView : UIView {
	
}

@end
