//
//  WhereAmIAppDelegate.h
//  WhereAmI
//
//  Created by doug chang on 9/19/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <MapKit/UIMapKit>

@interface WhereAmIAppDelegate : NSObject <UIApplicationDelegate,CLLocationManagerDelegate> {
    UIWindow *window;
	CLLocationManager *locationManager;
	UILabel *xLabel;
	UILabel *yLabel;
	UILabel *zLabel;
	UILabel *magnitudeLabel;
}

@property (nonatomic,retain) IBOutlet UILabel *xLabel;
@property (nonatomic,retain) IBOutlet UILabel *yLabel;
@property (nonatomic,retain) IBOutlet UILabel *zLabel;
@property (nonatomic,retain) IBOutlet UILabel *magnitudeLabel;


@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

