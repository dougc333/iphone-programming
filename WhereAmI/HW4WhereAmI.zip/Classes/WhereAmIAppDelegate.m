//
//  WhereAmIAppDelegate.m
//  WhereAmI
//
//  Created by doug chang on 9/19/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import "WhereAmIAppDelegate.h"

@implementation WhereAmIAppDelegate

@synthesize window,xLabel,yLabel,zLabel,magnitudeLabel;

-(void)locationManager:(CLLocationManager *) manager didUpdateToLocation:(CLLocation*)newLocation fromLocation:(CLLocation*)oldLocation{
	NSLog(@"%@",newLocation);
}

-(void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError*) error{
	NSLog(@"could not find location %@",error);
}


- (void)locationManager:(CLLocationManager *)manager didUpdateHeading:(CLHeading *)heading {
    // Update the labels with the raw x, y, and z values.
	//there are many ways to update text in a label. 
	xLabel.text = [NSString stringWithFormat:@"%.1f", heading.x];
	[yLabel setText:[NSString stringWithFormat:@"%.1f", heading.y]];
	[zLabel setText:[NSString stringWithFormat:@"%.1f", heading.z]];

    NSLog(@"heading.x:%.1f",heading.x);
    NSLog(@"heading.y:%.1f",heading.y);
    NSLog(@"heading.z:%.1f",heading.z);
	
    // Compute and display the magnitude (size or strength) of the vector magnitudeValue = sqrt(x^2 + y^2 + z^2);
	CGFloat magnitude = sqrt(heading.x*heading.x + heading.y*heading.y + heading.z*heading.z);
    [magnitudeLabel setText:[NSString stringWithFormat:@"%.5f", magnitude]];
	NSLog(@"magnitdue:%f", magnitude);
	// Update the graph with the new magnetic reading.
	//[graphView updateHistoryWithX:heading.x y:heading.y z:heading.z];
}


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    // Override point for customization after application launch
	// test memory leak using Run>>Build and Analyze, uses static analysis. 
	//	NSString *memoryLeak = [[NSString alloc] initWithFormat:@"%f",10.0]; 
	locationManager = [[CLLocationManager alloc]init];
	[locationManager setDelegate:self];
	[locationManager setDistanceFilter:kCLDistanceFilterNone];
	[locationManager setDesiredAccuracy:kCLLocationAccuracyBest];
	[locationManager startUpdatingLocation];
	if([locationManager headingAvailable]){
		NSLog(@"heading available, how the hell do you print a heading?");
		[locationManager startUpdatingHeading];
	}
	xLabel.text = [[NSString alloc] initWithFormat:@"%.1f",0.0 ];
	yLabel.text = [[NSString alloc] initWithFormat:@"%.1f",0.0 ];
	zLabel.text = [[NSString alloc] initWithFormat:@"%.1f",0.0 ];
	magnitudeLabel.text = [[NSString alloc] initWithFormat:@"%.1f",0.0 ];

    [window makeKeyAndVisible];
}



- (void)dealloc {
	[locationManager setDelegate:nil];
    [window release];
    [super dealloc];
}


@end
