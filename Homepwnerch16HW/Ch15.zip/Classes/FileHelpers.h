/*
 *  FileHelpers.h
 *  Homepwner
 *
 *  Created by doug chang on 11/5/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */
#import <UIKit/UIKit.h>

NSString *pathInDocumentDirectory(NSString *fileName);

