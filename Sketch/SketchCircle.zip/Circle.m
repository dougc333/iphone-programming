//
//  Circle.m
//  Sketch
//
//  Created by doug chang on 10/5/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Circle.h"


@implementation Circle
@synthesize firstTouch, secondTouch;

@end
