//
//  SketchView.m
//  Sketch
//
//  Created by doug chang on 10/3/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//


#import "SketchView.h"


@implementation SketchView


- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        // Initialization code
    }
    return self;
}


- (void)drawRect:(CGRect)rect {
    // Drawing code
	NSLog(@"draw rect numObjects in array:%d",[arr count]);
	CGContextRef myContext = UIGraphicsGetCurrentContext();
	CGContextSetLineWidth(myContext, 4.0);
	for (Circle *c in arr) {
		NSLog(@"circle firstTouch x:%f y;%f",c.firstTouch.x, c.firstTouch.y);
		NSLog(@"circle secondTouch x:%f y;%f",c.secondTouch.x, c.secondTouch.y);
		CGPoint center;
		center.x = c.firstTouch.x + (c.secondTouch.x - c.firstTouch.x)/2.0;
		center.y = c.firstTouch.y + (c.secondTouch.y - c.firstTouch.y)/2.0;
		float diam = hypot((c.secondTouch.x-c.firstTouch.x), (c.secondTouch.y - c.firstTouch.y));		
		CGContextAddArc(myContext, center.x, center.y, diam/2.0, 0.0, M_PI*2.0, YES);
		CGContextStrokePath(myContext);
	}
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
	NSLog(@"touchesBegan num in touch array:%d",[touches count]);
	UITouch *firstTouch;
	UITouch *secondTouch;
	if ([touches count]==2) {
		firstTouch = [[touches allObjects] objectAtIndex:0];
		secondTouch = [[touches allObjects] objectAtIndex:1];
		Circle *c = [[Circle alloc]init];
		c.firstTouch = [firstTouch locationInView:self];
		c.secondTouch = [secondTouch locationInView:self];
		[arr addObject:c];
		[self setNeedsDisplay];
		
	}else if ([touches count]==1) {
		firstTouch = [[touches allObjects] objectAtIndex:0];
		NSLog(@"firstTouch only tapCount:%d",[firstTouch tapCount]);
		
	}
	if ([firstTouch tapCount] > 1) {
		NSLog(@"tapcount>1 calling clearAll");
		[self clearAll];
		return;
	}
		
}

-(id)initWithCoder:(NSCoder *)aDecoder{
	if((self = [super initWithCoder:aDecoder])){
		arr = [[NSMutableArray alloc] init];
		self.multipleTouchEnabled = YES;
	}
	return self;
}

-(void)clearAll{
	NSLog(@"clearAll");
	[arr removeAllObjects];
	[self setNeedsDisplay];
}

- (void)dealloc {
	[arr dealloc];
    [super dealloc];
}


@end
