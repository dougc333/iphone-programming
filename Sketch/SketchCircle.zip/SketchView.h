//
//  SketchView.h
//  Sketch
//
//  Created by doug chang on 10/3/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Circle.h"

@interface SketchView : UIView {
	NSMutableArray * arr;
}


-(void)clearAll;
@end
